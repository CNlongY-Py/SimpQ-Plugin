import socket
import sys
import os
import time
PLUGINFO = {
    "name": "ConnectSDK",
    "version": "0.1",
    "author": "CNlongY",
    "libs": []
}

def main(log,bot):
    log.info("远程终端插件 %s已启动"%(PLUGINFO["version"]))
    # 创建 socket 对象
    serversocket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    # 获取本地主机名
    port = 5702
    # 绑定端口号
    serversocket.bind(("0.0.0.0", port))
    # 设置最大连接数，超过后排队
    serversocket.listen(3)
    while True:
        # 建立客户端连接
        clientsocket, addr = serversocket.accept()
        log_file = os.path.join("./logs", "{}.log".format(time.strftime("%Y-%m-%d", time.localtime())))
        with open(log_file,"r",encoding="utf-8")as f:
            msg=f.read()
            clientsocket.send(msg.split("\n")[len(msg.split("\n"))-2].encode('utf-8'))
        clientsocket.close()
def message(json, log, bot):
    pass