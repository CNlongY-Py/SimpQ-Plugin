import socket
import time
import sys
# 获取本地主机名

host = "localhost"
# 设置端口号
port = 5702
omsg=""
while True:
    # 创建 socket 对象
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    # 连接服务，指定主机和端口
    s.connect((host, port))
    msg = s.recv(1024)
    if msg!=omsg:
        omsg=msg
        print(msg.decode('utf-8'))
    s.close()
    time.sleep(1)

