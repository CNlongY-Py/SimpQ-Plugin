import yaml
PLUGINFO = {
    "name": "Acgkey",
    "version": "0.1",
    "author": "CNlongY",
    "libs": ["AcgLib"]
}
libs={}
def main(log, bot):
    log.info("ACG词库回复插件%s o(*////▽////*)q"%(PLUGINFO["version"]))
def createconfig(gid):
    with open("./plugins/ACGkey/config.yml","r")as f:
        yml=yaml.load(f,Loader=yaml.FullLoader)
        if not gid in yml:
            yml[gid]="off"
            with open("./plugins/ACGkey/config.yml","w")as a:
                a.write(yaml.dump(yml))
def message(json, log, bot):
    type = json["msgtype"]
    if type == "group":
        gid = json["gid"]
        uid = json["uid"]
        msg = json["msg"]
        createconfig(gid)
        if bot.getGroupUserInfo(gid, uid)["role"]!="member" or uid==3464356490:
            if msg.find("#ACG on")==0:
                with open("./plugins/ACGkey/config.yml", "r") as f:
                    yml = yaml.load(f,Loader=yaml.FullLoader)
                    yml[gid]="on"
                    with open("./plugins/ACGkey/config.yml", "w") as a:
                        a.write(yaml.dump(yml))
                log.debug("%s 群的ACG回复模式被%s 设置为on" % (gid, uid))
                bot.sendMsg("本群的ACG回复模式设置为on", gid)
            elif msg.find("#ACG off") == 0:
                with open("./plugins/ACGkey/config.yml", "r") as f:
                    yml = yaml.load(f,Loader=yaml.FullLoader)
                    yml[gid] = "off"
                    with open("./plugins/ACGkey/config.yml", "w") as a:
                        a.write(yaml.dump(yml))
                log.debug("%s 群的回ACG回复模式被%s 设置为off"%(gid,uid))
                bot.sendMsg("本群的ACG回复模式off",gid)
        for i in libs["AcgLib"].keylist:
            if msg.find(i)!=-1:
                with open("./plugins/ACGkey/config.yml", "r") as f:
                    yml = yaml.load(f,Loader=yaml.FullLoader)
                    if yml[gid]=="on":
                        bot.sendMsg(libs["AcgLib"].findkey(i),gid)
                        continue
