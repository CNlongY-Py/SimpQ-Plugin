import os
import time
import random
import yaml
PLUGINFO = {
    "name": "GroupGame",
    "version": "v0.1",
    "author": "CNlongY",
    "libs": []
}
path="./plugins/GroupGame"
def checkinfo(gid,uid):
    folderlist = os.listdir(path + "/config")
    if folderlist.count(str(gid)) == 0:
        os.mkdir(path + "/config/%s" % (gid))
    userlist = os.listdir(path + "/config/%s" % (gid))
    if userlist.count(str(uid)+".yml") == 0:
        with open(path + "/config/%s/%s.yml" % (gid, uid), "w") as f:
            with open(path + "/config/model.yml","r")as a:
                f.write(a.read())
    return True
def getweapon():
    with open(path + "/config/items/weapon.yml", "r", encoding="utf-8") as f:
        return yaml.load(f, Loader=yaml.FullLoader)
def getarrmor():
    with open(path + "/config/items/arrmor.yml", "r", encoding="utf-8") as f:
        return yaml.load(f, Loader=yaml.FullLoader)
def getuserinfo(uid,gid):
    with open(path + "/config/%s/%s.yml" % (gid, uid),"r",encoding='utf-8', errors='ignore')as f:
        return yaml.load(f,Loader=yaml.FullLoader)

def setuserinfo(uid, gid, data):
    with open(path + "/config/%s/%s.yml" % (gid, uid), "w",encoding="utf-8") as f:
        f.write(yaml.dump(data))
def main(log,bot):
    log.info("GroupGame %s加载成功"%(PLUGINFO["version"]))
def message(json, log, bot):
    type = json["msgtype"]
    if type == "group":
        gid = json["gid"]
        uid = json["uid"]
        msg = json["msg"]
        if msg.find("#打工")==0:
            checkinfo(gid, uid)
            info=getuserinfo(uid,gid)
            if info["money"]["work"]["type"]=="FREE":
                info["money"]["work"]["type"]="WORKING"
                info["money"]["work"]["time"] = int(time.time())
                setuserinfo(uid,gid,info)
                log.debug("%s 开始了打工 设置money/work/type为WORKING"%(uid))
                bot.sendMsg("[CQ:at,qq=%s]你开始了打工,在此期间你不能做任何事情"%(uid),gid)
            elif info["money"]["work"]["type"]=="WORKING":
                log.debug("%s 试图打工 检查money/work/type为WORKING"%(uid))
                bot.sendMsg("[CQ:at,qq=%s]你是想累死自己吗!"%(uid),gid)
        elif msg.find("#下班")==0:
            checkinfo(gid, uid)
            info = getuserinfo(uid, gid)
            if info["money"]["work"]["type"] == "WORKING":
                info["money"]["work"]["type"] = "FREE"
                getmoney = int((int(time.time()) - int(info["money"]["work"]["time"]))/10)
                info["money"]["inhand"]+=getmoney
                setuserinfo(uid,gid,info)
                allmoney=info["money"]["inbank"]+info["money"]["inhand"]
                log.debug("%s 打工结束 赚得%s瓶盖"%(uid,getmoney))
                bot.sendMsg("[CQ:at,qq=%s]打工结束,赚得%s瓶盖,当前余额%s瓶盖"%(uid,getmoney,allmoney),gid)
            elif info["money"]["work"]["type"] == "FREE":
                log.debug("%s 试图下班 检查money/work/type为FREE" % (uid))
                bot.sendMsg("[CQ:at,qq=%s]醒醒,你上班了吗!" % (uid), gid)
        elif msg.find("#查询")==0:
            checkinfo(gid, uid)
            info = getuserinfo(uid, gid)
            allmoney=info["money"]["inbank"]+info["money"]["inhand"]
            log.debug("%s 查询了信息"%(uid))
            bot.sendMsg("[CQ:at,qq=%s]你的身份信息\n-总资产%s瓶盖\n-现金%s瓶盖\n-存入银行%s瓶盖\n-当前状态%s"%(uid,allmoney,info["money"]["inhand"],info["money"]["inbank"],info["money"]["work"]["type"]),gid)
        elif msg.find("#")==0:
            checkinfo(gid, uid)
            info=getuserinfo(uid, gid)
            if info["money"]["work"]["type"]=="FREE":
                if msg.find("#存款")==0:
                    inhand=info["money"]["inhand"]
                    bank=msg.split(" ")
                    if len(bank)==2 and bank[1].isdigit() and int(bank[1])<=inhand:
                        bank=int(bank[1])
                        info["money"]["inhand"]-=bank
                        info["money"]["inbank"]+=bank
                        setuserinfo(uid, gid, info)
                        log.debug("%s 存入了银行 %s瓶盖"%(uid,bank))
                        bot.sendMsg("[CQ:at,qq=%s]已将%s存入银行 当前银行存款%s"%(uid,bank,info["money"]["inbank"]),gid)
                    elif len(bank)==2 and bank[1].isdigit() and int(bank[1])>inhand:
                        log.debug("%s 余额不足终止存款" % (uid))
                        bot.sendMsg("[CQ:at,qq=%s]余额不足,当前剩余%s瓶盖"%(uid,info["money"]["inhand"]),gid)
                elif msg.find("#取款")==0:
                    inbank = info["money"]["inbank"]
                    bank=msg.split(" ")
                    if len(bank)==2 and bank[1].isdigit() and int(bank[1])<=inbank:
                        bank = int(bank[1])
                        info["money"]["inbank"] -= bank
                        info["money"]["inhand"] += bank
                        setuserinfo(uid, gid, info)
                        log.debug("%s 从银行取出 %s瓶盖" % (uid, bank))
                        bot.sendMsg("[CQ:at,qq=%s]已将%s取出银行 当前现金存款%s" % (uid, bank, info["money"]["inhand"]),gid)
                    elif len(bank)==2 and bank[1].isdigit() and int(bank[1])>inbank:
                        log.debug("%s 余额不足终止取款" % (uid))
                        bot.sendMsg("[CQ:at,qq=%s]余额不足,当前剩余%s瓶盖" % (uid, info["money"]["inbank"]), gid)
                elif msg.find("#市场")==0 and len(msg.split(" "))==3:
                    typelist=msg.split(" ")
                    if typelist[1]=="武器":
                        if typelist[2]=="*":
                            weapon=getweapon()
                            msg="当前武器市场\n名称 售价 攻击力\n"
                            for i in weapon["weaponlist"]:
                                wmsg="-%s %s %s\n"%(i,weapon[i]["price"],weapon[i]["num"])
                                msg+=wmsg
                            bot.sendMsg(msg,gid)
                        else:
                            weapon = getweapon()
                            if weapon["weaponlist"].count(typelist[2])==1:
                                info=getuserinfo(uid,gid)
                                if info["money"]["inhand"]>=weapon[typelist[2]]["price"]:
                                    info["money"]["inhand"]-=weapon[typelist[2]]["price"]
                                    info["items"]["weapon"]["alllist"].append(typelist[2])
                                    setuserinfo(uid,gid,info)
                                    log.debug("%s 购买了武器 %s"%(uid,typelist[2]))
                                    bot.sendMsg("[CQ:at,qq=%s]购买成功,余额%s瓶盖"%(uid,info["money"]["inhand"]),gid)
                                elif info["money"]["inhand"]<weapon[typelist[2]]["price"]:
                                    log.debug("%s 试图购买武器 %s"%(uid,typelist[2]))
                                    bot.sendMsg("[CQ:at,qq=%s]余额不足,剩余%s瓶盖"%(uid,info["money"]["inhand"]),gid)
                    elif typelist[1]=="防具":
                        if typelist[2] == "*":
                            arrmor=getarrmor()
                            msg = "当前防具市场\n名称 售价 防御力 惩罚点\n"
                            for i in arrmor["arrmorlist"]:
                                wmsg = "-%s %s %s %s\n" % (i, arrmor[i]["price"], arrmor[i]["num"], arrmor[i]["hnum"])
                                msg += wmsg
                            bot.sendMsg(msg, gid)
                        else:
                            arrmor = getarrmor()
                            if arrmor["arrmorlist"].count(typelist[2])==1:
                                info=getuserinfo(uid,gid)
                                if info["money"]["inhand"]>=arrmor[typelist[2]]["price"]:
                                    info["money"]["inhand"]-=arrmor[typelist[2]]["price"]
                                    info["items"]["arrmor"]["alllist"].append(typelist[2])
                                    setuserinfo(uid,gid,info)
                                    log.debug("%s 购买了防具 %s"%(uid,typelist[2]))
                                    bot.sendMsg("[CQ:at,qq=%s]购买成功,余额%s瓶盖"%(uid,info["money"]["inhand"]),gid)
                                elif info["money"]["inhand"]<arrmor[typelist[2]]["price"]:
                                    log.debug("%s 试图购买防具 %s"%(uid,typelist[2]))
                                    bot.sendMsg("[CQ:at,qq=%s]余额不足,剩余%s瓶盖"%(uid,info["money"]["inhand"]),gid)
                elif msg.find("#物品")==0 and len(msg.split(" "))>=3:
                    typelist = msg.split(" ")
                    if typelist[1] == "武器":
                        if typelist[2] == "*":
                            info=getuserinfo(uid,gid)
                            bot.sendMsg("[CQ:at,qq=%s]你拥有以下武器\n%s"%(uid,info["items"]["weapon"]["alllist"]),gid)
                        else:
                            info = getuserinfo(uid, gid)
                            weapon = getweapon()
                            if info["items"]["weapon"]["alllist"].count(typelist[2])>0:
                                info["items"]["weapon"]["useweapon"]=typelist[2]
                                info["items"]["weapon"]["num"]=weapon[typelist[2]]["num"]
                                setuserinfo(uid,gid,info)
                                bot.sendMsg("[CQ:at,qq=%s]装备成功,当前攻击力%s"%(uid,info["items"]["weapon"]["num"]),gid)
                    elif typelist[1] == "防具":
                        if typelist[2] == "*":
                            info=getuserinfo(uid,gid)
                            bot.sendMsg("[CQ:at,qq=%s]你拥有以下防具\n%s"%(uid,info["items"]["arrmor"]["alllist"]),gid)
                        else:
                            info = getuserinfo(uid, gid)
                            arrmor = getarrmor()
                            if len(typelist)==4 and typelist[3]=="穿" and info["items"]["arrmor"]["alllist"].count(typelist[2]) > 0 and info["items"]["arrmor"]["hnum"]-arrmor[typelist[2]]["hnum"]>=0:
                                info["items"]["arrmor"]["hnum"] -= arrmor[typelist[2]]["hnum"]
                                info["items"]["arrmor"]["alllist"].remove(typelist[2])
                                info["items"]["arrmor"]["wearlist"].append(typelist[2])
                                info["items"]["arrmor"]["num"] += arrmor[typelist[2]]["num"]
                                setuserinfo(uid, gid, info)
                                log.debug("%s 装备了%s"%(uid,typelist[2]))
                                bot.sendMsg("[CQ:at,qq=%s]装备成功,当前防御力%s,惩罚点剩余%s" % (uid, info["items"]["arrmor"]["num"],info["items"]["arrmor"]["hnum"]), gid)
                            elif len(typelist)==4 and typelist[3]=="脱" and info["items"]["arrmor"]["wearlist"].count(typelist[2]) > 0:
                                info["items"]["arrmor"]["hnum"] += arrmor[typelist[2]]["hnum"]
                                info["items"]["arrmor"]["wearlist"].remove(typelist[2])
                                info["items"]["arrmor"]["alllist"].append(typelist[2])
                                info["items"]["arrmor"]["num"] -= arrmor[typelist[2]]["num"]
                                setuserinfo(uid,gid,info)
                                log.debug("%s 脱下了%s"%(uid,typelist[2]))
                                bot.sendMsg("[CQ:at,qq=%s]脱下防具,当前防御力%s,惩罚点剩余%s" % (uid, info["items"]["arrmor"]["num"],info["items"]["arrmor"]["hnum"]), gid)
                            elif len(typelist) == 4 and typelist[3] == "穿" and info["items"]["arrmor"]["hnum"] - arrmor[typelist[2]]["hnum"] <= 0:
                                log.debug("%s 试图穿上%s"%(uid,typelist[2]))
                                bot.sendMsg("[CQ:at,qq=%s]你装备太变态辣,惩罚点剩余%s" % (uid,info["items"]["arrmor"]["hnum"]), gid)
                            elif len(typelist) == 4 and typelist[3] == "脱" and info["items"]["arrmor"]["wearlist"].count(typelist[2]) == 0:
                                log.debug("%s 试图脱下%s" % (uid, typelist[2]))
                                bot.sendMsg("[CQ:at,qq=%s]你穿上它了吗" % (uid),gid)
                elif msg.find("#抢银行")==0:
                    info=getuserinfo(uid,gid)
                    rnum=random.randint(1,100)
                    if rnum<=10:
                        log.debug("%s 抢了银行 概率%s"%(uid,rnum))
                        info["money"]["inhand"]+=rnum%10*100
                        setuserinfo(uid,gid,info)
                        log.debug("%s洗劫了银行,获得%s"%(uid,rnum%10*100))
                        bot.sendMsg("[CQ:at,qq=%s]洗劫了银行,获得%s"%(uid,rnum%10*100),gid)
                    else:
                        log.debug("%s 失败了 获得%s分钟监禁"%(uid,rnum%10))
                        info["money"]["inhand"]-=rnum%10*10
                        setuserinfo(uid,gid,info)
                        bot.groupBan(gid,uid,rnum%10*60)
                        bot.sendMsg("[CQ:at,qq=%s] 获得%s分钟监禁,扣除%s瓶盖"%(uid,rnum%10,rnum%10*10),gid)
                elif msg.find("#洗劫")==0:
                    if msg.find("[CQ:at,qq=")!=-1:
                        qq=int(msg[msg.find("[CQ:at,qq=")+10:msg.find("]")])
                        selfuid=bot.getLoginInfo()["user_id"]
                        if selfuid==qq:
                            log.debug("%s 试图洗劫机器人"%(uid))
                            bot.sendMsg("[CQ:at,qq=%s]你是出生吗"%(uid),gid)
                        else:
                            sinfo=getuserinfo(uid,gid)
                            tinfo=getuserinfo(qq,gid)
                            if tinfo["money"]["inhand"]>100:
                                snum=sinfo["items"]["weapon"]["num"]
                                tnum=tinfo["items"]["arrmor"]["num"]
                                tmoney = random.randint(1, 5) * 10
                                if snum>tnum:
                                    tinfo["money"]["inhand"]-=tmoney
                                    sinfo["money"]["inhand"]+=tmoney
                                    setuserinfo(qq,gid,tinfo)
                                    setuserinfo(uid,gid,sinfo)
                                    log.debug("%s 洗劫成功 获得%s"%(uid,tmoney))
                                    bot.sendMsg("[CQ:at,qq=%s]洗劫成功 获得%s"%(uid,tmoney),gid)
                                else:
                                    bot.groupBan(gid, uid, tmoney*60)
                                    log.debug("%s 洗劫失败 监禁%s分钟"%(uid,tmoney))
                                    bot.sendMsg("[CQ:at,qq=%s]洗劫失败 被警察拷走监禁%s分钟"%(uid,int(tmoney/10)),gid)
                            else:
                                log.debug("%s 试图洗劫%s" % (uid,qq))
                                bot.sendMsg("[CQ:at,qq=%s]他太穷了,放过他吧" % (uid), gid)
            elif info["money"]["work"]["type"]=="WORKING":
                log.debug("%s 试图在工作时干其他事")
                bot.sendMsg("[CQ:at,qq=%s]你很忙,结束了手头上的工作再来找我吧"%(uid),gid)
            elif info["money"]["work"]["type"]=="JAIL":
                log.debug("%s 试图在关禁闭时干其他事")
                bot.sendMsg("[CQ:at,qq=%s]你在被关禁闭,注意你的行为!!!" % (uid), gid)
